module.exports = {
    config: {
        host: '127.0.0.1',
        user: 'www',
        password: 'hzc954325',
        database:'db_zyfjdcd',
        port: 3306
    }
};
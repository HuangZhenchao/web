var mysql = require('mysql');
var $db = require('../db');

// 使用连接池，提升性能
var pool  = mysql.createPool( $db.config);

// 向前台返回JSON方法的简单封装
var jsonWrite = function (res, ret) {
    if(typeof ret === 'undefined') {
        res.json({
            code:'1',
            msg: '操作失败'
        });
    } else {
        res.json(ret);
    }
};

module.exports = {
    list: function (req, res, next) {
        pool.getConnection(function(err, connection) {           
            var queryField=eval('(' + req.query.queryField + ')');
            var countStr='select count(*) as count from t_prescription where 1=1 '
            var sqlStr='select * from t_prescription where 1=1 '
            var tempStr=''
            for(var field in queryField){
                if(queryField[field]!=''){
                    sqlStr=sqlStr+' and '+field+' like \'%'+queryField[field]+'%\' '
                    countStr=countStr+' and '+field+' like \'%'+queryField[field]+'%\' '
                }                              
            }      
            console.log(sqlStr);
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });         
            connection.query(sqlStr,function(err, result) {
                
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                    
                });
                //jsonWrite(res, result);
                connection.release();
            });
            
        });
    },
    info: function (req, res, next) {
        var pres_id = +req.query.pres_id;
        var sqlStr='select * from t_prescription where id= '+pres_id
        console.log(sqlStr)
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr,function(err, result) {
                res.json({
                    code:20000,
                    data:result[0]                   
                });
                //jsonWrite(res, result);
                connection.release();
            });
        });
    },
    add: function (req, res, next) {
        var data=req.body;
        
        var sqlStr='insert into t_prescription (name,source,comprise,major,presUsage,preparation,effect,contraindication,annotation,eachexpound,addsubtract) \
        values (\''+data.name+'\',\''+data.source+'\',\''+data.comprise+'\',\''+data.major+'\',\''+data.presUsage
        +'\',\''+data.preparation+'\',\''+data.effect+'\',\''+data.contraindication+'\',\''+data.annotation+'\',\''+data.eachexpound+'\',\''
        +data.addsubtract+'\')'
        console.log(sqlStr)
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr,function(err, result) {
                res.json({
                    code:20000,                 
                });

                connection.release();
            });
        });
    },
    update: function (req, res, next) {
        var data=req.body;
        
        var sqlStr='update t_prescription set name=\''+data.name+'\',source=\''+data.source+'\',comprise=\''+data.comprise
        +'\',major=\''+data.major+'\',presUsage=\''+data.presUsage+'\',preparation=\''+data.preparation+'\',effect=\''+data.effect
        +'\',contraindication=\''+data.contraindication+'\',annotation=\''+data.annotation+'\',eachexpound=\''+data.eachexpound
        +'\',addsubtract=\''+data.addsubtract+'\' where id='+data.id
        console.log(sqlStr)
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr,function(err, result) {
                res.json({
                    code:20000,                  
                });

                connection.release();
            });
        });
    },
    delete:function (req, res, next){
        var postData=req.body;

        var sqlStr='delete from t_prescription where id= '+postData.id
        
        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },

};
var mysql = require('mysql');
var $db = require('../db');
var {dateFormat,dateStr}=require('../common/function')
// 使用连接池，提升性能
var pool  = mysql.createPool( $db.config);

module.exports = {
    list: function (req, res, next) {
        var queryField=eval('(' + req.query.queryField + ')');
        var countStr='select count(*) as count \
        from t_note a left join t_prescription b on a.pres_id=b.id left join t_userinfo c on a.userid=c.userid where '
        var sqlStr='select a.id,a.pres_id,c.username,b.name,b.comprise,a.content,a.createtime,a.lastedittime \
        from t_note a left join t_prescription b on a.pres_id=b.id left join t_userinfo c on a.userid=c.userid where '
        var whereStr=' 1=1'
        if(typeof(queryField['userid'])=='string'&&queryField['userid']!=''){
            whereStr=whereStr+' and a.userid=\''+queryField['userid']+'\''
        }
        if(typeof(queryField['pres_id'])=='number'){
            whereStr=whereStr+' and a.pres_id='+queryField['pres_id']
        }
        if(typeof(queryField['username'])=='string'&&queryField['username']!=''){
            whereStr=whereStr+' and c.username like \'%' +queryField['username'] +'%\''
        }
        if(typeof(queryField['prescName'])=='string'&&queryField['prescName']!=''){
            whereStr=whereStr+' and b.name like \'%' +queryField['prescName'] +'%\''
        }
        if(typeof(queryField['content'])=='string'&&queryField['content']!=''){
            whereStr=whereStr+' and a.content like \'%' +queryField['content'] +'%\''
        }
        countStr=countStr+whereStr
        sqlStr=sqlStr+whereStr
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    add: function (req, res, next) {
        var data=req.body
        var insertData={
            type:1,
            pres_id:1,
            field:'',
            userid:'',
            createtime:new Date(),
            lastedittime:new Date(),
            content:''
        }
        /*
        var whereStr=' 1=1'
        if(typeof(data['pres_id'])==='number'){
            whereStr=whereStr+' and a.pres_id='+data['pres_id']
        }
        if(typeof(data['userid'])==='string'&&data['userid']!=''){
            whereStr=whereStr+' and c.userid like \'%' +data['userid'] +'%\''
        }
        if(typeof(data['prescName'])==='string'&&data['prescName']!=''){
            whereStr=whereStr+' and b.name like \'%' +data['prescName'] +'%\''
        }
        if(typeof(data['content'])==='string'&&data['content']!=''){
            whereStr=whereStr+' and a.content like \'%' +data['content'] +'%\''
        }
        
        sqlStr=sqlStr+whereStr
        */
       insertData.type=data.type
       insertData.pres_id=data.pres_id
       insertData.userid=data.userid
       insertData.content=data.content
        var sqlStr='insert into t_note (type,pres_id,field,userid,createtime,lastedittime,content) \
        values ('+insertData.type+','+insertData.pres_id+',\''+insertData.field+'\',\''
        +insertData.userid+'\',\''+dateFormat(insertData.createtime)+'\',\''+dateFormat(insertData.lastedittime)+'\',\''+insertData.content+'\')'
        
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    data:{
                        total:1,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    delete:function (req, res, next){
        var postData=req.body;

        var sqlStr='delete from t_note where id= '+postData.id
        console.log(sqlStr)
        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },
}
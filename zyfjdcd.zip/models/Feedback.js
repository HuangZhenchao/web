var mysql = require('mysql');
var $db = require('../db');
var {dateFormat,dateStr}=require('../common/function')
// 使用连接池，提升性能
var pool  = mysql.createPool( $db.config);

module.exports = {
    errorlist: function (req, res, next) {
        var queryField=eval('(' + req.query.queryField + ')');
        
        var countStr='select  count(*) as count  \
        from t_feedback_error  a left join t_userinfo b on a.userid=b.userid left join t_prescription c on a.pres_id=c.id where'
        var sqlStr='select b.username,a.*,c.name as pres_name  \
        from t_feedback_error  a left join t_userinfo b on a.userid=b.userid left join t_prescription c on a.pres_id=c.id where'
        
        var whereStr=' 1=1'
        if(queryField['username']!=''){
            whereStr=whereStr+' and b.username like \'%'+queryField['username'] +'%\''
        }
        if(queryField['content']!=''){
            whereStr=whereStr+' and a.content like \'%'+queryField['content'] +'%\''
        }
        if(queryField['detail']!=''){
            whereStr=whereStr+' and a.detail like \'%'+queryField['detail'] +'%\''
        }
        if(queryField['status']!=0){
            whereStr=whereStr+' and a.status='+queryField['status']
        }
        countStr=countStr+whereStr
        sqlStr=sqlStr+whereStr
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });
            connection.query(sqlStr, function(err, result) {
                
                console.log(result);
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    lacklist: function (req, res, next) {
        var queryField=eval('(' + req.query.queryField + ')');
        
        var countStr='select  count(*) as count  \
        from t_feedback_lack  a left join t_userinfo b on a.userid=b.userid where'
        
        var sqlStr='select b.username,a.*  \
        from t_feedback_lack  a left join t_userinfo b on a.userid=b.userid where'
        
        var whereStr=' 1=1'
        if(queryField['username']!=''){
            whereStr=whereStr+' and b.username like \'%'+queryField['username'] +'%\''
        }
        if(queryField['content']!=''){
            whereStr=whereStr+' and a.content like \'%'+queryField['content'] +'%\''
        }
        if(queryField['detail']!=''){
            whereStr=whereStr+' and a.detail like \'%'+queryField['detail'] +'%\''
        }
        if(queryField['status']!=0){
            whereStr=whereStr+' and a.status='+queryField['status']
        }
        countStr=countStr+whereStr
        sqlStr=sqlStr+whereStr
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });
            connection.query(sqlStr, function(err, result) {
                
                console.log(result);
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    suggestlist: function (req, res, next) {
        var queryField=eval('(' + req.query.queryField + ')');
        var countStr='select count(*) as count  \
        from t_feedback_suggest  a left join t_userinfo b on a.userid=b.userid where'
        var sqlStr='select b.username,a.*  \
        from t_feedback_suggest  a left join t_userinfo b on a.userid=b.userid where'
        
        var whereStr=' 1=1'
        if(queryField['username']!=''){
            whereStr=whereStr+' and b.username like \'%'+queryField['username'] +'%\''
        }
        if(queryField['content']!=''){
            whereStr=whereStr+' and a.content='+queryField['content']
        }
        if(queryField['status']!=''){
            whereStr=whereStr+' and a.status='+queryField['status']
        }
        countStr=countStr+whereStr
        sqlStr=sqlStr+whereStr
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });
            connection.query(sqlStr, function(err, result) {
                
                console.log(result);
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    erroradd: function (req, res, next) {
        var data=req.body
        var insertData={
            userid:'',
            pres_id:0,            
            content:'',            
            detail:'',
            time:new Date(),
            status:0,
        }
        insertData.pres_id=data.pres_id
        insertData.userid=data.userid
        insertData.content=data.content
        var sqlStr='insert into t_feedback_error (userid,pres_id,time,content,detail) \
        values (\''+insertData.userid+'\','+insertData.pres_id+',\''+dateFormat(insertData.time)+'\',\''
        +insertData.content+'\',\''+insertData.detail+'\')'

        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    msg:'提交了一个错误'
                });
                connection.release();
            });
        });
    },
    lackadd: function (req, res, next) {
        var data=req.body
        var insertData={
            userid:'',        
            content:'',            
            detail:'',
            time:new Date(),
            status:0,
        }
        insertData.pres_id=data.pres_id
        insertData.userid=data.userid
        insertData.content=data.content
        var sqlStr='insert into t_feedback_lack (userid,time,content,detail) \
        values (\''+insertData.userid+'\',\''+dateFormat(insertData.time)+'\',\''
        +insertData.content+'\',\''+insertData.detail+'\')'

        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    msg:'报告了一个缺失'
                });
                connection.release();
            });
        });
    },
    suggestadd: function (req, res, next) {
        var data=req.body
        var insertData={
            userid:'',         
            content:'',            
            detail:'',
            time:new Date(),
            status:0,
        }
        insertData.pres_id=data.pres_id
        insertData.userid=data.userid
        insertData.content=data.content
        var sqlStr='insert into t_feedback_suggest (userid,time,content,detail) \
        values (\''+insertData.userid+'\',\''+dateFormat(insertData.time)+'\',\''
        +insertData.content+'\',\''+insertData.detail+'\')'

        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    msg:'提交了一个建议'
                });
                connection.release();
            });
        });
    },
}
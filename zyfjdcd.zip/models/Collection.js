var mysql = require('mysql');
var $db = require('../db');
var {dateFormat,dateStr}=require('../common/function')
// 使用连接池，提升性能
var pool  = mysql.createPool( $db.config);

module.exports = {
    list: function (req, res, next) {
        var queryField=eval('(' + req.query.queryField + ')');
        var countStr='select count(*) as count  \
        from t_collect a left join t_prescription b on a.pres_id=b.id left join t_userinfo c on a.userid=c.userid where'
        var sqlStr='select a.id,a.pres_id,c.username,b.name,b.comprise,a.time,a.detail  \
        from t_collect a left join t_prescription b on a.pres_id=b.id left join t_userinfo c on a.userid=c.userid where'
        console.log(sqlStr);
        var whereStr=' 1=1'
        if(queryField['username']!=''){
            whereStr=whereStr+' and c.username like \'%'+queryField['username'] +'%\''
        }
        if(queryField['prescName']!=''){
            whereStr=whereStr+' and b.name like \'%'+queryField['prescName']+'%\''
        }
        if(queryField['detail']!=''){
            whereStr=whereStr+' and a.detail like \'%'+queryField['detail'] +'%\''
        }
        countStr=countStr+whereStr
        sqlStr=sqlStr+whereStr
        pool.getConnection(function(err, connection) {
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });
            connection.query(sqlStr, function(err, result) {
                
                console.log(result);
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
        });
    },
    add: function (req, res, next) {
        var data=req.body
        var insertData={
            userid:'',
            pres_id:1,            
            time:new Date(),
            detail:''
        }

       insertData.pres_id=data.pres_id
       insertData.userid=data.userid
       insertData.detail=data.detail
        var sqlStr='insert into t_collect (userid,pres_id,time,detail) \
        values (\''+insertData.userid+'\','+insertData.pres_id+',\''+dateFormat(insertData.time)+'\',\''
        +insertData.detail+'\')'
        
        console.log(sqlStr);
        pool.getConnection(function(err, connection) {
            connection.query(sqlStr, function(err, result) {        
                console.log(result);                      
                res.json({
                    code:20000,
                    msg:'收藏方剂成功'
                });
                connection.release();
            });
        });
    },
    delete:function (req, res, next){
        var postData=req.body;

        var sqlStr='delete from t_collect where id= '+postData.id
        
        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },
}
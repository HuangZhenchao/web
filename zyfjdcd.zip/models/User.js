var mysql = require('mysql');
var $db = require('../db');
const jwt=require('jsonwebtoken')
var {dateFormat,dateStr}=require('../common/function')
// 使用连接池，提升性能
var pool  = mysql.createPool( $db.config);

// 向前台返回JSON方法的简单封装
var jsonWrite = function (res, ret) {
    if(typeof ret === 'undefined') {
        res.json({
            code:'1',
            msg: '操作失败'
        });
    } else {
        res.json(ret);
    }
};
const tokens = {
    admin: {
      token: 'admin-token'
    },
    editor: {
      token: 'editor-token'
    }
  };
  
  const users = {
    'admin-token': {
      roles: ['admin'],
      introduction: 'I am a super administrator',
      avatar: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
      name: 'Super Admin'
    },
    'editor-token': {
      roles: ['editor'],
      introduction: 'I am an editor',
      avatar: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
      name: 'Normal Editor'
    }
  };
module.exports = {
    login: function (req, res, next) {
        var postData=req.body;
        pool.getConnection(function(err, connection) {
            var sqlStr='select * from t_userinfo where username=\''+postData.username+'\''
            console.log(sqlStr)
            connection.query(sqlStr, function(err, result) {
                var flag=0
                if(Object.keys(result).length>0){
                    if(result[0].passwd===postData.password){
                        console.log(result[0])
                        let token=jwt.sign({username:postData.username},'zyfjdcd',{})
                        console.log(token)
                        res.json({
                            code:20000,
                            data: {
                                token: token,
                                userid:result[0].userid,
                                role:result[0].role,
                                username:postData.username,
                                avatar:'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
                            },
                        });
                    }else{
                        flag=1
                    }
                    
                }else{
                    flag=1
                }
                if(flag>0){
                    res.json({
                        code:'1',
                        msg: '用户不存在'
                    });
                }
                connection.release();
            });
        });
    },
    logout: function (req, res, next) {
        pool.getConnection(function(err, connection) {
            res.json({
                code: 20000,
                data: 'success'
            });
            /*
            connection.query($sql.queryAll, function(err, result) {
                jsonWrite(res, result);
                connection.release();
            });
            */
        });
    }, 
    list: function (req, res, next) {
        var id = +req.query.id;
        pool.getConnection(function(err, connection) {   
            var queryField=eval('(' + req.query.queryField + ')');
            var countStr='select count(*) as count  from t_userinfo where 1=1 '
            var sqlStr='select * from t_userinfo where 1=1 '
            for(var field in queryField){
                if(queryField[field]!=''){
                    sqlStr=sqlStr+' and '+field+' like \'%'+queryField[field]+'%\' '
                    countStr=countStr+' and '+field+' like \'%'+queryField[field]+'%\' '
                }          
            }      
            console.log(countStr);
            var count=0
            connection.query(countStr, function(err, result) {
                count=result[0]['count']
            });    
            connection.query(sqlStr, function(err, result) {
                
                console.log(result);
                res.json({
                    code:20000,
                    data:{
                        total:count,
                        items:result
                    }
                });
                connection.release();
            });
            
        });
    },
    add:function (req, res, next){
        var postData=req.body;

        postData['userid']='ZYFJDCD'+dateStr(new Date())+(Math.floor(Math.random()*(9999-1000))+1000)      
        postData['regtime']= dateFormat(new Date());
         var sqlStr='insert into t_userinfo ('
        var index=0
        for(var data in postData){
            if(index!=0){
                sqlStr=sqlStr+','
            }
            sqlStr=sqlStr+data         
            index++          
        }   
        index=0  
        sqlStr=sqlStr+') values (' 
        for(var data in postData){
            if(index!=0){
                sqlStr=sqlStr+','
            }
            //if(postData[data].isS)
            sqlStr=sqlStr+'\''+postData[data]+'\''
            index++            
        }
        sqlStr=sqlStr+');' 
        console.log(sqlStr);

        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },
    edit:function (req, res, next){
        var postData=req.body;
    
        postData['regtime']= dateFormat(postData['regtime']);
        var sqlStr='update t_userinfo set '
        var index=0
        for(var data in postData){
            if(index!=0){
                sqlStr=sqlStr+','
            }
            if(data=='userid'){
                continue
            }
            sqlStr=sqlStr+data+'=\''+ postData[data]+'\''   
            index++          
        }   
       
        sqlStr=sqlStr+' where userid=\''+postData['userid']+'\''

        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },
    info: function (req, res, next) {
        var id = +req.query.id;
        //1.获得前端传递来的token     可以是get，post请求传递 也可以在请求头
        let token=req.query.token || req.body.token || req.headers.token;
        //2.token  检验token
        console.log(token)
        var data={}
        jwt.verify(token,'zyfjdcd',(err,decode)=>{
            console.log('err',err)  //null 表示没有报错
            console.log('decode',decode)
            data=decode
        })

        var sqlStr='select * from t_userinfo where username=\''+data.username+'\''
        pool.getConnection(function(err, connection) {
                       
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                    data: {                        
                        userid:result[0].userid,
                        role:result[0].role,
                        username:data.username,
                        avatar:'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
                    },
                });
                connection.release();

            });
            
        });
    },
    delete:function (req, res, next){
        var postData=req.body;

        var sqlStr='delete from t_userinfo where userid=\''+postData.userid+'\''
        console.log(sqlStr)
        pool.getConnection(function(err, connection) {                             
            connection.query(sqlStr, function(err, result) {
                res.json({
                    code:20000,
                });
                connection.release();
            });
            
        });
    },

};
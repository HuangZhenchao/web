var express = require('express');
var router = express.Router();
var Note= require('../models/Note');
/* GET users listing. */

router.get('/list', function(req, res, next) {
    console.log('/Note/list');
    Note.list(req, res, next);
});
router.post('/add', function(req, res, next) {
    console.log('/Note/add');
    Note.add(req, res, next);
});
router.post('/edit', function(req, res, next) {
    console.log('/Note/edit');
    Note.edit(req, res, next);
});
router.post('/delete', function(req, res, next) {
    console.log('/Note/delete');
    Note.delete(req, res, next);
});
module.exports = router;
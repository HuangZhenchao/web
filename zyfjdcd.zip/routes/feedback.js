var express = require('express');
var router = express.Router();
var Feedback= require('../models/Feedback');
/* GET users listing. */

router.get('/suggestlist', function(req, res, next) {
    console.log('/Feedback/suggestlist');
    Feedback.suggestlist(req, res, next);
});
router.get('/errorlist', function(req, res, next) {
    console.log('/Feedback/errorlist');
    Feedback.errorlist(req, res, next);
});
router.get('/lacklist', function(req, res, next) {
    console.log('/Feedback/lacklist');
    Feedback.lacklist(req, res, next);
});
router.post('/suggestadd', function(req, res, next) {
    console.log('/Feedback/suggestadd');
    Feedback.suggestadd(req, res, next);
});
router.post('/erroradd', function(req, res, next) {
    console.log('/Feedback/erroradd');
    Feedback.erroradd(req, res, next);
});
router.post('/lackadd', function(req, res, next) {
    console.log('/Feedback/lackadd');
    Feedback.lackadd(req, res, next);
});
router.post('/edit', function(req, res, next) {
    console.log('/Feedback/edit');
    Feedback.edit(req, res, next);
});
module.exports = router;
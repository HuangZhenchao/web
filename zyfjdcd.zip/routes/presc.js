var express = require('express');
var router = express.Router();
var Presc= require('../models/Presc');
/* GET users listing. */

router.get('/list', function(req, res, next) {
    console.log('/presc/list');
    Presc.list(req, res, next);
});
router.get('/info', function(req, res, next) {
    console.log('/presc/info');
    Presc.info(req, res, next);
});
router.post('/add', function(req, res, next) {
    console.log('/presc/add');
    Presc.add(req, res, next);
});
router.post('/update', function(req, res, next) {
    console.log('/presc/update');
    Presc.update(req, res, next);
});
router.post('/delete', function(req, res, next) {
    console.log('/presc/delete');
    Presc.delete(req, res, next);
});
module.exports = router;
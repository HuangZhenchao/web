var express = require('express');
var router = express.Router();
var User= require('../models/User');
/* GET users listing. */

router.post('/login', function(req, res, next) {
    console.log('/user/login');
    User.login(req, res, next);
});
router.post('/logout', function(req, res, next) {
    console.log('/user/logout');
    User.logout(req, res, next);
});
router.get('/info', function(req, res, next) {
    console.log('/user/info');
    User.info(req, res, next);
});
router.get('/list', function(req, res, next) {
    console.log('/user/list');
    User.list(req, res, next);
});
router.post('/add', function(req, res, next) {
    console.log('/user/add');
    User.add(req, res, next);
});
router.post('/edit', function(req, res, next) {
    console.log('/user/edit');
    User.edit(req, res, next);
});
router.post('/delete', function(req, res, next) {
    console.log('/user/delete');
    User.delete(req, res, next);
});
module.exports = router;
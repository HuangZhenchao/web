var express = require('express');
var router = express.Router();
var Collection= require('../models/Collection');
/* GET users listing. */


router.get('/list', function(req, res, next) {
    console.log('/Collection/list');
    Collection.list(req, res, next);
});
router.post('/add', function(req, res, next) {
    console.log('/Collection/add');
    Collection.add(req, res, next);
});
router.post('/edit', function(req, res, next) {
    console.log('/Collection/edit');
    Collection.edit(req, res, next);
});
router.post('/delete', function(req, res, next) {
    console.log('/Collection/delete');
    Collection.delete(req, res, next);
});
module.exports = router;
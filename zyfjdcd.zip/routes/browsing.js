var express = require('express');
var router = express.Router();
var Browsing= require('../models/Browsing');
/* GET users listing. */

router.get('/list', function(req, res, next) {
    console.log('/Browsing/list');
    Browsing.list(req, res, next);
});
router.post('/add', function(req, res, next) {
    console.log('/Browsing/add');
    Browsing.add(req, res, next);
});
router.post('/edit', function(req, res, next) {
    console.log('/Browsing/edit');
    Browsing.edit(req, res, next);
});
router.post('/delete', function(req, res, next) {
    console.log('/Browsing/delete');
    Browsing.delete(req, res, next);
});
module.exports = router;
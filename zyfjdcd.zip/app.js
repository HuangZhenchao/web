const express = require('express')
const app = express()
const path = require('path') 
const port = 3001
var bodyParser = require('body-parser');

var user = require('./routes/user');
var presc = require('./routes/presc');
var note = require('./routes/note');
var collection = require('./routes/collection');
var browsing = require('./routes/browsing');
var feedback = require('./routes/feedback');
const history = require('connect-history-api-fallback')
app.use('/', history());
app.use(express.static(path.join(__dirname, 'vue/dist')))
// 解析 application/json
app.use(bodyParser.json()); 
// 解析 application/x-www-form-urlencoded
app.use(bodyParser.urlencoded());
app.use('/api/user', user);
app.use('/api/presc', presc);
app.use('/api/note', note);
app.use('/api/collection', collection);
app.use('/api/browsing', browsing);
app.use('/api/feedback', feedback);
app.listen(port, () => console.log(`Example app listening on port ${port}!`))